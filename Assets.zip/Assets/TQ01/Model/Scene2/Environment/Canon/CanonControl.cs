using UnityEngine;

public class CanonControl : MonoBehaviour
{
    [SerializeField]GameObject body;
    [SerializeField]GameObject gun;
    Quaternion StartbodyRotation;
    Quaternion StartgunRotation;

    GameObject Enemy;
    void Start()
    {
        StartbodyRotation = body.transform.rotation;
        StartgunRotation = gun.transform.rotation;

    }

    void OnTriggerEnter(Collider other)
    {
        if (Enemy == null && other.gameObject.CompareTag("enemy"))
            Enemy = other.gameObject;
             // Enemy.GetComponent<FindDestination>().GetTurret(gameObject);
            
            
            
    }
    void OnTriggerExit(Collider other)
    {

        if (other.gameObject.CompareTag("enemy") && Enemy != null && other.gameObject == Enemy)
        {
            //Enemy.GetComponent<FindDestination>().CLearTurret();
            Enemy = null;

        }
    }
    void GunRotate(Vector3 aim)
    {
        float distance_Target = Vector3.Distance(aim, gun.transform.position);
        var relativeTargetPos = gun.transform.position + (gun.transform.forward * distance_Target);
        relativeTargetPos = new Vector3(relativeTargetPos.x, Enemy.transform.position.y, relativeTargetPos.z);

        gun.transform.rotation = Quaternion.Lerp(gun.transform.rotation, Quaternion.LookRotation(relativeTargetPos - gun.transform.position), Time.deltaTime * 1.5f);
        //Goc lech so voi ban dau
        //float angle = Vector3.Angle(body.transform.forward, relativeTargetPos - gun.transform.position);

        //if (angle <= 40)
        //{

        //}

    }
    void CoreRotate(Vector3 aim)
    {
        body.transform.rotation = Quaternion.Slerp(body.transform.rotation, Quaternion.LookRotation(aim - body.transform.position), Time.deltaTime * 2.5f);
    }
    void Update()
    {
        if (Enemy != null)
        {
            // Implement logic to control the gun against the current enemy

            // For example, you might want to rotate the gun towards the enemy
            var AimAt = new Vector3(Enemy.transform.position.x, body.transform.position.y, Enemy.transform.position.z);
            body.transform.rotation = Quaternion.Slerp(body.transform.rotation, Quaternion.LookRotation(AimAt - body.transform.position), Time.deltaTime * 2.5f);

            //float dist_Target = Vector3.Distance(AimAt, gun.transform.position);

            //var relativeTargetPos = gun.transform.position + (gun.transform.forward * dist_Target);

            //relativeTargetPos = new Vector3(relativeTargetPos.x, Enemy.transform.position.y, relativeTargetPos.z);

            ////Goc lech so voi ban dau
            //float angle = Vector3.Angle(body.transform.forward, relativeTargetPos - gun.transform.position);
            //if (angle<= 40)
            //{

            //    gun.transform.rotation = Quaternion.Lerp(gun.transform.rotation, Quaternion.LookRotation(relativeTargetPos - gun.transform.position), Time.deltaTime * 1.5f);
            //}

            //body.transform.rotation = Quaternion.Slerp(body.transform.rotation, Quaternion.LookRotation(AimAt - body.transform.position), Time.deltaTime * 2.5f);

           // CoreRotate(AimAt);
            GunRotate(AimAt);


            Vector3 directionToTarget = Enemy.transform.position - gun.transform.position;

            if (Vector3.Angle(directionToTarget, gun.transform.forward) < 16)
            {


              
            }
            else
            {
              

            }

        }
        //else
        //{
        //    gun.transform.localRotation = Quaternion.Lerp(gun.transform.localRotation, StartgunRotation, Time.deltaTime);
        //    body.transform.localRotation = Quaternion.Lerp(body.transform.localRotation, StartbodyRotation, Time.deltaTime);
            

        //}
    }
}
