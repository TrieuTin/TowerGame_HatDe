using UnityEngine;

public class CanonControl : MonoBehaviour
{
    [SerializeField]GameObject body;
    [SerializeField]GameObject gun;
    Quaternion StartbodyRotation;
    Quaternion StartgunRotation;

    [SerializeField] GameObject cannonballPrefab;
    [SerializeField] Transform holeOfGun;
    float fireForce = 5;
    public float fireCooldown = 2f;   
    private float cooldownTimer = 0f;

    GameObject Enemy;
    [SerializeField] UnityEngine.UI.Slider Blood_Prefab;
    private UnityEngine.UI.Slider _blood;

    GameSound gamesound;

    private void Awake()
    {
        gamesound = GameObject.FindGameObjectWithTag("Audio").GetComponent<GameSound>();
    }
    void Start()
    {
        StartbodyRotation = body.transform.rotation;
        StartgunRotation = gun.transform.rotation;
        if (Blood_Prefab)
        {

            _blood = Instantiate(Blood_Prefab, this.transform.position, Quaternion.identity);
            _blood.transform.SetParent(GameObject.Find("Canvas").transform);

        }
        else MessageShow("Blood prefab is null");
    }
    void MessageShow(string text)
    {
        Debug.Log(text);
    }
    void OnTriggerEnter(Collider other)
    {
        if (Enemy == null && other.gameObject.CompareTag("enemy"))
            Enemy = other.gameObject;
             // Enemy.GetComponent<FindDestination>().GetTurret(gameObject);
            
            
            
    }
    void OnTriggerExit(Collider other)
    {

        if (other.gameObject.CompareTag("enemy") && Enemy != null && other.gameObject == Enemy)
        {
            //Enemy.GetComponent<FindDestination>().CLearTurret();
            Enemy = null;

        }
    }
    public void Fire()
    {
        if (cannonballPrefab == null || holeOfGun == null) return;

        
        GameObject bullet = Instantiate(cannonballPrefab, holeOfGun.position, holeOfGun.rotation);

        var cb = bullet.GetComponent<CanonBall>();
        if (cb != null)
        {
            cb.speed = fireForce;
            cb.Launch(holeOfGun.forward); // direction
                                          // gamesound.PlaySFX(gamesound.shot,.5f);
            Audio.Shot(.6f);
        }
    }
    void Update()
    {
        if (_blood) //show bloodbar on head
        {
            Renderer rend = GetComponentInChildren<Renderer>();
            float height = rend.bounds.size.y;
            Vector3 top = rend.bounds.center + Vector3.up * (height / 2);
            Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .8f);
            _blood.GetComponent<RectTransform>().position = screenPos;



        }


        if (Enemy != null)
        {
            cooldownTimer -= Time.deltaTime;

            gun.transform.rotation = LookGameObject.Rotate_CoordinateAxis_X(Enemy, body);           

            body.transform.rotation = LookGameObject.Rorate_CoordinateAxis_Y(Enemy, gun);

           

            Vector3 directionToTarget = Enemy.transform.position - gun.transform.position;

            //MessageShow(Vector3.Angle(directionToTarget, gun.transform.forward).ToString());
            if (Vector3.Angle(directionToTarget, gun.transform.forward) <= 88)
            {

                if (cooldownTimer <= 0f)
                {
                    Fire();
                    cooldownTimer = fireCooldown; // wait 2s 
                }
            }
            else
            {
              

            }

        }
        //else
        //{
        //    gun.transform.localRotation = Quaternion.Lerp(gun.transform.localRotation, StartgunRotation, Time.deltaTime);
        //    body.transform.localRotation = Quaternion.Lerp(body.transform.localRotation, StartbodyRotation, Time.deltaTime);


        //}
    }
}
