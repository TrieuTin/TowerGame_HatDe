using System;
using UnityEngine;

public class CanonBall : MonoBehaviour
{
    public float speed = 2f;       
    public float lifeTime = 3.0f;    
    public int damage = 50;
    Rigidbody rb;
    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
    }
    private void OnEnable()
    {
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
        Invoke(nameof(DestroySelf), lifeTime);
    }

    private void DestroySelf()
    {
        CancelInvoke(nameof(DestroySelf));
        Destroy(gameObject);
    }
    void OnCollisionEnter(Collision collision)
    {
        Rigidbody rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        var damageable = collision.collider.GetComponent<IDamageable>();
        if (damageable != null)
        {
            damageable.TakeDamage(damage);
        }
        //test
        // TODO: Exlosion here

        //destroy after collider
        DestroySelf();
    }
    public void Launch(Vector3 direction)
    {
        if (rb == null) rb = GetComponent<Rigidbody>();

        rb.AddForce(direction.normalized * speed, ForceMode.VelocityChange);
    }


}
