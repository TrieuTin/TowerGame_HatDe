using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class CanonAgent : MonoBehaviour
{


    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;

    [SerializeField] Slider Health_Prefab;
    private Slider _health;
    

    void Start()
    {
        _health = Instantiate(Health_Prefab, this.transform.position, Quaternion.identity);
        _health.transform.SetParent(GameObject.Find("Canvas").transform);

        if (_health)
        {
            _health.maxValue = 100;
            _health.value = Random.Range(1, _health.maxValue + 1);

        }

        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

    private void Delete_Object()
    {
        _agent.ResetPath();
        Destroy(this.gameObject);
        Destroy(this._health.gameObject);
    }

    void Update()
    {
        if (_agent.remainingDistance <= .1f)
        {
            Delete_Object();
        }
        if (_health) //show bloodbar on head
        {
            Renderer rend = GetComponentInChildren<Renderer>();
            float height = rend.bounds.size.y;
            Vector3 top = rend.bounds.center + Vector3.up * (height / 2);
            Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .5f); 
            _health.GetComponent<RectTransform>().position = screenPos;


            
        }
    }
}
