using UnityEngine;
using UnityEngine.AI;

public class CanonAgent : MonoBehaviour
{


    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;
    void Start()
    {
        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

    private void Delete_Object()
    {
        _agent.ResetPath();
        Destroy(this.gameObject);
    }

    void Update()
    {
        if (_agent.remainingDistance <= .1f)
        {
            Delete_Object();
        }
    }
}
