using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class CanonAgent : MonoBehaviour,IDamageable
{


    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;

    [SerializeField] Slider Health_Prefab;
    private Slider _health;

    [SerializeField] const int max_Blood=100;
    private int currentBlood = 0;

    GameSound gamesound;
    private void Awake()
    {
        var sndManager = GameObject.FindGameObjectWithTag("Audio");

        gamesound = sndManager.GetComponent<GameSound>();
    }

    void Start()
    {
        //Audio = GetComponent<AudioSource>();
       
        _health = Instantiate(Health_Prefab, this.transform.position, Quaternion.identity);
        _health.transform.SetParent(GameObject.Find("Canvas").transform);

        if (_health)
        {
            currentBlood = max_Blood;
            _health.maxValue = max_Blood;
            _health.value = currentBlood;

        }

        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

    private void Delete_Object()
    {
        
        _agent.ResetPath();
        Destroy(this.gameObject);
        Destroy(this._health.gameObject);
    }

    void Update()
    {
        if (_agent.remainingDistance <= .1f)
        {
            Delete_Object();
        }
        if (_health) //show bloodbar on head
        {
            Renderer rend = GetComponentInChildren<Renderer>();

            float height = rend.bounds.size.y;

            Vector3 top = rend.bounds.center + Vector3.up * (height / 2);

            Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .5f); 

            _health.GetComponent<RectTransform>().position = screenPos;


            
        }
    }

    public void TakeDamage(int amount)
    {
        if(_health.value > 0)
        {
            if (amount > 0) currentBlood -= amount;

            _health.value = currentBlood;
        }
        else
        {
            Delete_Object();
            Effect.DisplayExplosion(this.gameObject.transform.position);
            // gamesound.PlaySFX(gamesound.death);

           // Audio.Explotion();
        }
    }
}
