using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildTower : MonoBehaviour
{
    [SerializeField] GameObject MenuPopup;
    [SerializeField] GameObject[] ListTower;
    GameObject InstantObj;
    Collider _pedestalCollider;
    public void ActiveMenu(bool show = true)
    {
        MenuPopup.SetActive(show);

    }
    public void Canon()
    {
        ActiveMenu(false);
        if (ListTower[0] != null)
        {
            Create_Instant(ListTower[0]);
           
        }
        
    }
    public void Catapult()
    {
        ActiveMenu(false);
        if (ListTower[1] != null)
        {
            Create_Instant(ListTower[1]);

        }

    }
    void Create_Instant(GameObject Obj)
    {
       
        ActiveMenu(false);

        if (_pedestalCollider)
        {
            InstantObj = Instantiate(Obj, _pedestalCollider.gameObject.transform.position, Quaternion.identity);

            Bounds bounds = _pedestalCollider.bounds;

            var pedestalTop_Y = bounds.max.y;

            var turretHeight = InstantObj.GetComponent<BoxCollider>().bounds.size.y;

            if (InstantObj != null)
            {
                InstantObj.transform.position = new Vector3(_pedestalCollider.transform.position.x, pedestalTop_Y, _pedestalCollider.transform.position.z);
                InstantObj.GetComponent<BoxCollider>().enabled = true;
                InstantObj.GetComponent<SphereCollider>().enabled = true;
                _pedestalCollider.tag = "Occupied";

                //InstantObj.GetComponent<GunControl>().Platform = _pedestalCollider.gameObject;


            }

        }

        InstantObj = null;

    }
   

    TouchPhase Tap
    {
        get
        {

            if (Input.touchCount > 0)
            {
                switch (Input.GetTouch(0).phase)
                {
                    case TouchPhase.Began:
                        {
                            //Begin tap
                            return TouchPhase.Began;
                        }
                    case TouchPhase.Moved:
                        {
                            //Move finger
                            return TouchPhase.Moved;
                        }
                    case TouchPhase.Stationary:
                        {
                            //Touch long time
                            return TouchPhase.Stationary;
                        }
                    case TouchPhase.Ended:
                        {
                            //End tap
                            return TouchPhase.Ended;
                        }

                    default:
                        //Cancel tap
                        return TouchPhase.Canceled;
                }
            }
            else return TouchPhase.Canceled;
        }
    }
    Vector2 Position_Of_Tap => Input.GetTouch(0).position;

    RaycastHit GetHit_ExceptLayer(string LayerName)
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return default;
        }
        else
        {

            Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);

            if (Physics.Raycast(ray, out var hit, Mathf.Infinity, ~(1 << LayerMask.NameToLayer(LayerName))))
            {
                
                return hit;
            }
            return default;
        }
    }
    void Show_MenuBuild()
    {
        var hit = GetHit_ExceptLayer("Turret");
        var collider = hit.collider;

        

        if (hit.collider && collider.gameObject.CompareTag("Platform"))
        {
            _pedestalCollider = collider;
            ActiveMenu();

            MenuPopup.transform.position = Position_Of_Tap;

            //order the last row to show on top
            MenuPopup.transform.SetAsLastSibling();
        }
    }
    RaycastHit GetHit()
    {
        // Click UI
        if (EventSystem.current.IsPointerOverGameObject())
        {
            return default;
        }
        else
        {
            Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);

            if (Physics.Raycast(ray, out var hit))
            {
                return hit;
            }
            else
            {
                return default;
            }
        }
    }
   
    void ShowMessage(string message)
    {
        Debug.Log(message);

    }
    // Update is called once per frame
    void Update()
    {
        if (Tap == TouchPhase.Began)
        {
            
            Show_MenuBuild();

        }

    }
   
}
