using UnityEngine;

public class GameSound : MonoBehaviour
{
    [Header("-------Audio Source--------")]
    [SerializeField] AudioSource SFXSourece;
    [SerializeField] AudioSource Background;
    [Header("-------Audio Clip--------")]
    public AudioClip death;
    public AudioClip shot;
    public AudioClip music;


    public void PlaySFX(AudioClip clip , float amountVolumn=1f)
    {
        SFXSourece.PlayOneShot(clip, amountVolumn);
    }
    private void Start()
    {
        playMusic();
    }
    public void playMusic(bool isPlay=true)
    {
        Background.clip = music;
        Background.loop = true;
        if (isPlay)
        {

            Background.Play();
        }
        else
        {
            Background.Stop();
        }
    }
    
}
