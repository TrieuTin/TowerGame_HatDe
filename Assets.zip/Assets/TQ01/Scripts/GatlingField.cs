using UnityEngine;

[CreateAssetMenu(fileName = "GatlingField", menuName = "ScriptableObjects/GatlingField")]
public class GatlingField : ScriptableObject
{
    public string Name;
    public int Heath;
    public int Damage;
    public  int Level =1;
    public int Rate;
   
}
