using System;
using UnityEngine;
using UnityEngine.Pool;
public class ReturnToPool : MonoBehaviour
{
    public ParticleSystem system;
    AudioSource sound;
    [SerializeField] AudioClip clip;
    public IObjectPool<ParticleSystem> pool;


    void Start()
    {
        sound = gameObject.GetComponent<AudioSource>();
        sound.clip = clip;

        var main = system.main;
        main.stopAction = ParticleSystemStopAction.Callback;
    }
    void OnEnable()
    {
        if (sound)
            sound.Play();

    }
    void OnParticleSystemStopped()
    {
        if (pool != null)
            pool.Release(system);
    }

}
