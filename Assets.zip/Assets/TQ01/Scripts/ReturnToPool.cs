using System;
using UnityEngine;
using UnityEngine.Pool;
public class ReturnToPool : MonoBehaviour
{
    public ParticleSystem system;
   
    public IObjectPool<ParticleSystem> pool;


    void Start()
    {      
        var main = system.main;
        main.stopAction = ParticleSystemStopAction.Callback;
    }
    void OnEnable()
    {
        Audio.Explotion();
    }
    void OnParticleSystemStopped()
    {
        if (pool != null)
            pool.Release(system);
    }

}
