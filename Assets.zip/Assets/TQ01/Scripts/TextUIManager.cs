using UnityEngine;
using UnityEngine.SceneManagement;
public class TextUIManager : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }
   
}
