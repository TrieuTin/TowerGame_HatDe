using Unity.Mathematics;
using UnityEngine;
using UnityEngine.UI;


public class GunControl : MonoBehaviour
{
    AudioSource Sound;
    AudioClip Clip;
    GameObject currentEnemy;
    public GameObject bodyCore;
    public GameObject gun;
    public GatlingField Data1;
    public GatlingFieldsLevel2 Data2;

    public GameObject ModelLevel2;


    public int Level = 1;

    int currentHealthy = 0;
    int rate;
    
    Slider Heathy;
    int damage;
    Quaternion StartbodyRotation;
    Quaternion StartgunRotation;
   
    [SerializeField] Slider Heathy_Prefab;


    [Header("Let's it empty for now")]
    public GameObject Platform;





    void Start()
    {

      

        StartbodyRotation = bodyCore.transform.rotation;
        StartgunRotation = gun.transform.rotation;
        Sound = gameObject.GetComponent<AudioSource>();

        damage = Data1.Damage;
        rate = Data1.Rate;
        currentHealthy = Data1.Heath;


        Heathy = Instantiate(Heathy_Prefab, this.transform.position, Quaternion.identity);
        Heathy.transform.SetParent(GameObject.Find("Canvas").transform);

        if (Heathy != null)
        {

            Heathy.maxValue = currentHealthy;
            Heathy.value = currentHealthy;
        }

        var am = GameObject.Find("AudioSystem");
        if (am)
        {
            Clip = am.GetComponent<AudioPlay>().clip_Shoot1;
            Sound.clip = Clip;

        }




    }
    public void Hit(int hit)
    {
        currentHealthy -= hit;
        Heathy.value = currentHealthy;
        Heathy.GetComponent<StatusHeath>().SetHealth(currentHealthy, Heathy.maxValue);


        if (currentHealthy <= 0) Death();
    }
    void Death()
    {
        DragGun.DisplayExplosion(this.gameObject.transform.position);
        DragError();

        if (Platform)
        {
            Platform.tag = "Platform";
        }
    }
    public void DragError()
    {
        Destroy(gameObject);
        Destroy(Heathy.gameObject);
    }
    void OnTriggerEnter(Collider other)
    {
        if (currentEnemy == null)
            if (other.gameObject.CompareTag("enemy"))
            {
                currentEnemy = other.gameObject;
                currentEnemy.GetComponent<FindDestination>().GetTurret(gameObject);
            }
    }
    void OnTriggerExit(Collider other)
    {

        if (other.gameObject.CompareTag("enemy") && currentEnemy != null && other.gameObject == currentEnemy)
        {
            currentEnemy.GetComponent<FindDestination>().CLearTurret();
            currentEnemy = null;

        }
    }
    void Shoot()
    {
        if (currentEnemy)
        {
            int rnd = UnityEngine.Random.Range(1, 100);

            if (Level == 2)
            {
                rate = Data2.Rate;
                damage = Data2.Damame;
            }

            if (rnd < rate)
                currentEnemy.GetComponent<FindDestination>().Hit(damage);
        }
    }
    void OnTriggerStay(Collider other)
    {

    }
    // Update is called once per frame
    void Update()
    {
        if (currentEnemy != null)
        {
            // Implement logic to control the gun against the current enemy

            // For example, you might want to rotate the gun towards the enemy
            var AimAt = new Vector3(currentEnemy.transform.position.x, bodyCore.transform.position.y, currentEnemy.transform.position.z);

            float dist_Target = Vector3.Distance(AimAt, gun.transform.position);

            var relativeTargetPos = gun.transform.position + (gun.transform.forward * dist_Target);

            relativeTargetPos = new Vector3(relativeTargetPos.x, currentEnemy.transform.position.y, relativeTargetPos.z);

            gun.transform.rotation = Quaternion.Lerp(gun.transform.rotation, Quaternion.LookRotation(relativeTargetPos - gun.transform.position), Time.deltaTime * 2.5f);

            bodyCore.transform.rotation = Quaternion.Slerp(bodyCore.transform.rotation, Quaternion.LookRotation(AimAt - bodyCore.transform.position), Time.deltaTime * 2.5f);

            Vector3 directionToTarget = currentEnemy.transform.position - gun.transform.position;

            if (Vector3.Angle(directionToTarget, gun.transform.forward) < 16)
            {
               

                if (Sound != null)
                    if (!Sound.isPlaying)
                    {

                        Sound.Play();

                        Shoot();
                    }
            }
            else
            {
                Sound.Stop();
               
            }

        }
        else
        {
            gun.transform.localRotation = Quaternion.Lerp(gun.transform.localRotation, StartgunRotation, Time.deltaTime);
            bodyCore.transform.localRotation = Quaternion.Lerp(bodyCore.transform.localRotation, StartbodyRotation, Time.deltaTime);
            Sound.Stop();
         
        }


        if (Heathy)
        {
            Heathy.transform.position = Camera.main.WorldToScreenPoint(gameObject.transform.position + Vector3.up * 0.4f);
        }
    }
}
