using System;
//using Unity.Android.Gradle.Manifest;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Pool;
using UnityEngine.UI;
public class DragGun : MonoBehaviour
{
    public TMPro.TextMeshProUGUI DebugText;
    [SerializeField] TMPro.TextMeshProUGUI txtGun1;
    [SerializeField] TMPro.TextMeshProUGUI txtGun2;
    [SerializeField] Button btn_Gun1;
    [SerializeField] Button btn_Gun2;

    private int qtyGun1=7;
    private int qtyGun2=03;
    //private int attacked=0;

    public GameObject[] Guns;
    public GameObject turretMenu;

    public ParticleSystem deathParticle_Prefab;
    public static IObjectPool<ParticleSystem> deathParPool;
    GameObject InstantObj;
    Collider _pedestalCollider;
    GameObject turretDestroy;

    public bool isDragging=false;
    void Start()
    {
        deathParPool = new ObjectPool<ParticleSystem>(CreateDeathExp, OnTakeFromPool, OnReturnToPool, null, true, 10, 20);
        txtGun1.text = string.Format("{0}", qtyGun1);
        txtGun2.text = string.Format("{0}", qtyGun2);

    }
    void Show_Qty_Gun1()
    {
        if (qtyGun1 > 0) qtyGun1--;
        txtGun1.text = string.Format("{0}", qtyGun1);
    }
    void Show_Qty_Gun2()
    {
        if (qtyGun2 > 0) qtyGun2--;
        txtGun2.text = string.Format("{0}", qtyGun2);
    }
    public void Message(string message)
    {
        DebugText.text = string.Format("{0}", message);
    }
    ParticleSystem CreateDeathExp()
    {
        ParticleSystem ps = Instantiate(deathParticle_Prefab);
        ps.Stop();
        return ps;
    }
    void OnReturnToPool(ParticleSystem ps)
    {
        ps.gameObject.SetActive(false);
    }
    void OnTakeFromPool(ParticleSystem ps)
    {
        //ps.gameObject.SetActive(true);
        ps.gameObject.SetActive(true);

        var returnToPool = ps.GetComponent<ReturnToPool>();
        if (returnToPool != null)
        {
            returnToPool.pool = deathParPool; // Gán pool vào script
        }
    }
    public static void DisplayExplosion(Vector3 pos)
    {
        ParticleSystem deathExp = deathParPool.Get();
        if (deathExp)
        {
            deathExp.transform.position = pos;
            deathExp.Play();

        }
    }
    public void DragGun1()
    {
        if (Guns[0] != null)
        {
            if (qtyGun1 > 0)
            {
                Create_Instant(Guns[0]);
                Show_Qty_Gun1();
            }
            else ActiveMenu(false);
        }
        else { Debug.LogError("Guns is null"); ActiveMenu(false); }
    }
    public void DragGun2()
    {
        if (Guns[1] != null)
        {
            if (qtyGun2 > 0)
            {

                Create_Instant(Guns[1]);
                Show_Qty_Gun2();
            }
            else ActiveMenu(false);
        }
        else { Debug.LogError("Guns is null"); ActiveMenu(false); }
    }
    void Create_Instant(GameObject Obj)
    {
        //var hit = GetHit();


        //if (hit.collider != null)
        //{
        //    InstantObj = Instantiate(Obj, hit.point, Quaternion.identity);

        //    if (InstantObj != null)
        //    {
        //        InstantObj.GetComponent<BoxCollider>().enabled = false;
        //        InstantObj.GetComponent<SphereCollider>().enabled = false;
        //    }

        //}
        ActiveMenu(false);
        
        if (_pedestalCollider)
        {
            InstantObj = Instantiate(Obj, _pedestalCollider.gameObject.transform.position, Quaternion.identity);

            Bounds bounds = _pedestalCollider.bounds;
            var pedestalTop_Y = bounds.max.y;
            var turretHeight = InstantObj.GetComponent<BoxCollider>().bounds.size.y;

            if (InstantObj != null)
            {
                InstantObj.transform.position = new Vector3(_pedestalCollider.transform.position.x, pedestalTop_Y , _pedestalCollider.transform.position.z);
                InstantObj.GetComponent<BoxCollider>().enabled = true;
                InstantObj.GetComponent<SphereCollider>().enabled = true;
                _pedestalCollider.tag = "Occupied";

                InstantObj.GetComponent<GunControl>().Platform = _pedestalCollider.gameObject;
               

            }

        }

        InstantObj = null;    

    }
  
    public void Upgrade_Turret()
    {
        ActiveMenu(false);
        if (turretDestroy)
        {
            var pedestal = turretDestroy.GetComponent<GunControl>().Platform;
            pedestal.tag = "Platform";

            var data = turretDestroy.GetComponent<GunControl>().Data2;
            var lvel = turretDestroy.GetComponent<GunControl>().Level;
            if (lvel == 1)
            {
                var newTurret = Instantiate(turretDestroy.GetComponent<GunControl>().ModelLevel2, turretDestroy.transform.position, Quaternion.identity);

                newTurret.transform.position = turretDestroy.transform.position;

                turretDestroy.GetComponent<GunControl>().DragError();

                lvel = 2;
                
            }
            else Debug.Log("Already UpDated");
        }
    }
    public void ActiveMenu(bool show=true)
    {
        turretMenu.SetActive(show);

    }
    //them vao nut destroy trong menu
    public void DestroyMe()
    {
        ActiveMenu(false);
        if (turretDestroy)
        {
            

             var pedestal = turretDestroy.GetComponent<GunControl>().Platform;

            pedestal.tag = "Platform";

            DragGun.DisplayExplosion(turretDestroy.transform.position);


            turretDestroy.GetComponent<GunControl>().DragError();
            turretDestroy = null;
        }
      
    }

    void Show_MenuBuild()
    {
        var hit = GetHit2();

        var collider = hit.collider;

        if (hit.collider != null && collider.gameObject.CompareTag("Platform"))
        {
            _pedestalCollider = collider;

           

           btn_Gun1.interactable = qtyGun1 > 0;
            btn_Gun2.interactable = qtyGun2 > 0;

            ActiveMenu();

            turretMenu.transform.position = Position_Of_Tap;

            //order the last row to show on top
            turretMenu.transform.SetAsLastSibling();
        }
    }
    TouchPhase Tap
    {
        get
        {

            if (Input.touchCount > 0)
            {
                switch (Input.GetTouch(0).phase)
                {
                    case TouchPhase.Began:
                        {
                            //Begin tap
                            return TouchPhase.Began;
                        }
                    case TouchPhase.Moved:
                        {
                            //Move finger
                            return TouchPhase.Moved;
                        }
                    case TouchPhase.Stationary:
                        {
                            //Touch long time
                            return TouchPhase.Stationary;
                        }
                    case TouchPhase.Ended:
                        {
                            //End tap
                            return TouchPhase.Ended;
                        }

                    default:
                        //Cancel tap
                        return TouchPhase.Canceled;
                }
            }
            else return TouchPhase.Canceled;
        }
    }
   Vector3 Position_Of_Tap
    {
        get => Input.GetTouch(0).position;
    }
    
    
    void Update()
    {
        if (Tap == TouchPhase.Began)
        {
            Show_MenuBuild();

        }

        /*we can change Input.GetMouseButtonDown = (Input.GetTouch(0))*/
        //if (Input.GetMouseButtonDown(1))// )(Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) //Click mouse event
        //{
        //    var hit = GetHit2();

        //    var turret = hit.collider.gameObject;

        //    if (hit.collider != null && turret.CompareTag("turret"))
        //    {
        //        turretMenu.SetActive(true);

        //        turretDestroy = turret;

        //        turretMenu.transform.position = Input.mousePosition;
        //        //order the last row to show on top
        //        turretMenu.transform.SetAsLastSibling();
        //    }

        //}
        //else 
        //if (Input.GetMouseButton(0)) // drag mouse event
        //{
        //    var hit = GetHit();
        //    if (hit.collider && InstantObj)
        //    {

        //        InstantObj.transform.position = hit.point;

        //        if (InstantObj) isDragging = true;
        //    }
        //}
        //else if (Input.GetMouseButtonUp(0)) //leave mouse event
        //{
        //    var hit = GetHit();

        //    if (hit.collider != null)
        //    {


        //        var pedestals = hit.collider.gameObject;


        //        if (hit.collider != null && pedestals.CompareTag("Platform"))
        //        {
        //            if (InstantObj != null)
        //            {
        //                InstantObj.transform.position = new Vector3(pedestals.transform.position.x, InstantObj.transform.position.y, pedestals.transform.position.z);
        //                InstantObj.GetComponent<BoxCollider>().enabled = true;
        //                InstantObj.GetComponent<SphereCollider>().enabled = true;
        //                pedestals.tag = "Occupied";

        //                InstantObj.GetComponent<GunControl>().Platform = pedestals;

        //                isDragging = false;

        //            }

        //        }

        //        else
        //        {
        //            if (InstantObj)
        //                InstantObj.GetComponent<GunControl>().DragError();
        //        }
        //    }
        //}

        //if (!isDragging) return;

        //if (Input.touchCount > 0)
        //{
        //    Touch touch = Input.GetTouch(0);
        //    Message(Input.GetTouch(0).position.x.ToString());
        //    var hit = GetHit();
        //    if(touch.phase == TouchPhase.Began)
        //    {
        //        if (Prefab)
        //        {
        //            InstantObj = Instantiate(Prefab, hit.point, Quaternion.identity);
        //        }
        //    }

        //    if (touch.phase == TouchPhase.Moved)
        //    {
        //        // Drag finger
        //        if (hit.collider && InstantObj)
        //        {

        //            InstantObj.transform.position = hit.point;

                   
        //        }
        //    }

        //    if (touch.phase == TouchPhase.Ended)
        //    {
        //        // Release finger
              

        //        if (hit.collider != null)
        //        {


        //            var pedestals = hit.collider.gameObject;


        //            if (hit.collider != null && pedestals.CompareTag("Platform"))
        //            {
        //                if (InstantObj != null)
        //                {
        //                    InstantObj.transform.position = new Vector3(pedestals.transform.position.x, InstantObj.transform.position.y, pedestals.transform.position.z);
        //                    InstantObj.GetComponent<BoxCollider>().enabled = true;
        //                    InstantObj.GetComponent<SphereCollider>().enabled = true;
        //                    pedestals.tag = "Occupied";

        //                    InstantObj.GetComponent<GunControl>().Platform = pedestals;


        //                }

        //            }

        //            else
        //            {
        //                if (InstantObj)
        //                    InstantObj.GetComponent<GunControl>().DragError();
        //            }
        //        }
        //    }
        //}
        //InstantObj = null;
        //isDragging = false;
    }

    RaycastHit GetHit()
    {

        Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);

        if (!Physics.Raycast(ray, out var hit, Mathf.Infinity, ~(1 << LayerMask.NameToLayer("Turret"))))
        {

           
            return hit;
        }
        return default;


    }
    RaycastHit GetHit2()
    {

        Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);
        if (!Physics.Raycast(ray, out var hit))
        {

            return hit;

        }
        return hit;
    }

}
