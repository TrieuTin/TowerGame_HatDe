﻿using UnityEngine;

public class CamMove : MonoBehaviour
{
    public float dragSpeed = 5f;

    private Vector3 dragOrigin;

    // Update is called once per frame
    void Update()
    {
#if UNITY_EDITOR || UNITY_STANDALONE  // PC (Mouse)

        var DragGun = GameObject.Find("GameManager");
        if (DragGun)
        {
            var isDrag = DragGun.GetComponent<DragGun>().isDragging;
            
            if (isDrag) return;
        }
        

        if (Input.GetMouseButtonDown(0)) // start drag
        {
            dragOrigin = Input.mousePosition;
        }

        if (Input.GetMouseButton(0)) // dragging
        {
            Vector3 pos = Camera.main.ScreenToViewportPoint(Input.mousePosition - dragOrigin);
            Vector3 move = new Vector3(pos.x , 0, -pos.y * dragSpeed);

            transform.Translate(move, Space.World);
            dragOrigin = Input.mousePosition;
        }
#endif

#if UNITY_ANDROID || UNITY_IOS  // Mobile (Touch)
        //if (Input.touchCount == 1) // 1 ngón tay
        //{
        //    Touch touch = Input.GetTouch(0);

        //    if (touch.phase == TouchPhase.Moved)
        //    {
        //        Vector3 delta = touch.deltaPosition;
        //        Vector3 move = new Vector3(-delta.x, 0, -delta.y) * dragSpeed * Time.deltaTime;

        //        transform.Translate(move, Space.World);
        //    }
        //}
#endif
    }
}
