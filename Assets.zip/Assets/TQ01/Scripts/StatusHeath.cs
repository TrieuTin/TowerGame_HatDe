using UnityEngine;
using UnityEngine.UI;

public class StatusHeath : MonoBehaviour
{
    [SerializeField] private Slider slider;
    [SerializeField] private Image fill;

    private Color highColor = Color.green;
    private Color midColor = new Color(1f, 0.5f, 0f); // cam
    private Color lowColor = Color.red;
    public void SetHealth(float current, float max)
    {
        float percent = current / max;

        if (percent > 0.5f) // trên 50% máu
        {
            fill.color = highColor;
        }
        else if (percent > 0.35f) // từ 15% đến 50%
        {
            fill.color = midColor;
        }
        else // dưới 15%
        {
            fill.color = lowColor;
        }
    }



}
