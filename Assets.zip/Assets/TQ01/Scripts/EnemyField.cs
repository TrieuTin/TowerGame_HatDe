using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/EnemyField", order = 1)]
public class EnemyField : ScriptableObject
{
    public string Name;
    public int Heath;
    public int Damage;
    public float Speed;

    public int Rate;

}
