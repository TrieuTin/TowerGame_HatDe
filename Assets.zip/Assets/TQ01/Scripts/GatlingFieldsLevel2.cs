using UnityEngine;

[CreateAssetMenu(fileName = "GatlingFieldsLevel2", menuName = "ScriptableObjects/GatlingFieldsLevelHigh")]
public class GatlingFieldsLevel2 : ScriptableObject
{
    public string Name;
    public int Damame =25;
    public  int Level = 2;
    public int Heath =250;
    public int Rate =80;
}
